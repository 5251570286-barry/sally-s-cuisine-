import {
  Coffee,
  Flame,
  Leaf,
  Salad,
  Soup,
  Sparkles,
  Sprout,
  Utensils,
  Wheat,
  type LucideIcon,
} from 'lucide-react';

export interface MenuItem {
  id: string;
  name: string;
  image: string;
  icon: LucideIcon;
}

export const MENU_ITEMS: MenuItem[] = [
  { id: 'indomie', name: 'Indomie', image: '/images/menu/indomie.jpg', icon: Soup },
  { id: 'spaghetti', name: 'Spaghetti', image: '/images/menu/spaghetti.jpg', icon: Utensils },
  { id: 'hot-tea', name: 'Hot Tea', image: '/images/menu/hot-tea.jpg', icon: Coffee },
  { id: 'wheat-porridge', name: 'Wheat Porridge', image: '/images/menu/wheat-porridge.jpg', icon: Wheat },
  { id: 'oat-porridge', name: 'Oat Porridge', image: '/images/menu/oat-porridge.jpg', icon: Leaf },
  { id: 'fried-yam', name: 'Fried Yam', image: '/images/menu/fried-yam.jpg', icon: Flame },
  { id: 'rice-porridge', name: 'Rice Porridge', image: '/images/menu/rice-porridge.jpg', icon: Sprout },
  { id: 'salad-cream', name: 'Salad Cream', image: '/images/menu/salad-cream.jpg', icon: Salad },
  { id: 'kelewele', name: 'Kelewele', image: '/images/menu/kelewele.jpg', icon: Sparkles },
];

export function findMenuItem(id: string) {
  return MENU_ITEMS.find((item) => item.id === id);
}
