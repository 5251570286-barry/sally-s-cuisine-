import type { ReactNode } from 'react';
import { MapPin, MessageCircle, Phone, Store, Truck, type LucideIcon } from 'lucide-react';
import Reveal from '@/components/Reveal';
import { GENERAL_ORDER_URL, WHATSAPP_DISPLAY_NUMBER } from '@/lib/whatsapp';

export default function Contact() {
  return (
    <section id="contact" className="relative bg-cream-200/70 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-700">Visit & Order</p>
          <h2 className="mt-4 text-4xl font-semibold text-forest-900 sm:text-5xl">We would love to hear from you</h2>
          <div className="gold-rule mt-6" />
          <p className="mt-6 text-base leading-relaxed text-forest-700">
            Message us on WhatsApp to order, ask about prices, or arrange pickup or delivery.
          </p>
        </Reveal>

        <div className="mt-16 grid gap-6 md:grid-cols-3">
          <Reveal>
            <ContactCard icon={MapPin} title="Location" tone="Find us in">
              <p className="text-lg font-medium text-forest-900">Winneba Zongo, Ghana</p>
            </ContactCard>
          </Reveal>

          <Reveal delay={100}>
            <ContactCard icon={Phone} title="WhatsApp" tone="Call or message">
              <a
                href={GENERAL_ORDER_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="text-lg font-medium text-forest-900 underline-offset-4 transition hover:text-forest-600 hover:underline"
              >
                {WHATSAPP_DISPLAY_NUMBER}
              </a>
            </ContactCard>
          </Reveal>

          <Reveal delay={200}>
            <ContactCard icon={Store} title="Pickup & Delivery" tone="Your choice">
              <p className="flex items-center gap-2 text-lg font-medium text-forest-900">
                <Store size={18} className="text-forest-600" />
                Pickup
                <span className="text-forest-400">or</span>
                <Truck size={18} className="text-forest-600" />
                Delivery
              </p>
            </ContactCard>
          </Reveal>
        </div>

        <Reveal delay={150} className="mt-16 flex justify-center">
          <a
            href={GENERAL_ORDER_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 rounded-full bg-forest-700 px-10 py-5 text-base font-semibold text-cream-50 shadow-lift transition duration-300 hover:-translate-y-1 hover:bg-forest-600"
          >
            <MessageCircle size={20} />
            Order on WhatsApp
          </a>
        </Reveal>
      </div>
    </section>
  );
}

interface ContactCardProps {
  icon: LucideIcon;
  title: string;
  tone: string;
  children: ReactNode;
}

function ContactCard({ icon: Icon, title, tone, children }: ContactCardProps) {
  return (
    <div className="group h-full rounded-3xl border border-forest-100 bg-cream-50 p-8 shadow-soft transition duration-500 hover:-translate-y-1 hover:border-gold-500/50 hover:shadow-lift">
      <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-forest-700 text-gold-300 transition duration-500 group-hover:bg-gold-500 group-hover:text-forest-900">
        <Icon size={22} />
      </span>
      <p className="mt-6 text-xs font-semibold uppercase tracking-[0.2em] text-gold-700">{title}</p>
      <p className="mt-1 text-sm text-forest-600">{tone}</p>
      <div className="mt-4">{children}</div>
    </div>
  );
}
