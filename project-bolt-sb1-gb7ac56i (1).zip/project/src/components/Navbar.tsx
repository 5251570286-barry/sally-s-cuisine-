import { useEffect, useState } from 'react';
import { MessageCircle, Menu, X } from 'lucide-react';
import Logo from '@/components/Logo';
import { GENERAL_ORDER_URL } from '@/lib/whatsapp';

const NAV_LINKS = [
  { href: '#home', label: 'Home' },
  { href: '#menu', label: 'Menu' },
  { href: '#gallery', label: 'Gallery' },
  { href: '#about', label: 'About Sally' },
  { href: '#contact', label: 'Contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const closeMenu = () => setOpen(false);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled || open
          ? 'bg-cream-50/95 py-3 shadow-soft backdrop-blur-md'
          : 'bg-transparent py-5'
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 sm:px-8" aria-label="Main">
        <a href="#home" onClick={closeMenu} className="shrink-0">
          <Logo size="sm" />
        </a>

        <ul className="hidden items-center gap-8 lg:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className={`group relative text-sm font-medium tracking-wide transition-colors ${
                  scrolled ? 'text-forest-800 hover:text-forest-600' : 'text-cream-50 hover:text-gold-300'
                }`}
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 h-px w-0 bg-gold-500 transition-all duration-300 group-hover:w-full" />
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-3">
          <a
            href={GENERAL_ORDER_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden items-center gap-2 rounded-full bg-gold-500 px-5 py-2.5 text-sm font-semibold text-forest-900 shadow-soft transition duration-300 hover:-translate-y-0.5 hover:bg-gold-400 sm:inline-flex"
          >
            <MessageCircle size={18} />
            Order on WhatsApp
          </a>
          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? 'Close menu' : 'Open menu'}
            className={`inline-flex h-11 w-11 items-center justify-center rounded-full border transition lg:hidden ${
              scrolled || open
                ? 'border-forest-200 text-forest-800 hover:bg-forest-50'
                : 'border-cream-50/40 text-cream-50 hover:bg-cream-50/10'
            }`}
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </nav>

      <div
        id="mobile-menu"
        className={`grid overflow-hidden transition-all duration-500 lg:hidden ${
          open ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
        }`}
      >
        <div className="min-h-0">
          <div className="mx-5 mt-4 flex flex-col gap-1 rounded-2xl border border-forest-100 bg-cream-50 p-3 shadow-soft sm:mx-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={closeMenu}
                className="rounded-xl px-4 py-3 text-base font-medium text-forest-800 transition hover:bg-forest-50"
              >
                {link.label}
              </a>
            ))}
            <a
              href={GENERAL_ORDER_URL}
              target="_blank"
              rel="noopener noreferrer"
              onClick={closeMenu}
              className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-gold-500 px-5 py-3 text-sm font-semibold text-forest-900 transition hover:bg-gold-400"
            >
              <MessageCircle size={18} />
              Order on WhatsApp
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
