import { ArrowDown, MessageCircle, MapPin } from 'lucide-react';
import ImageWithFallback from '@/components/ImageWithFallback';
import Logo from '@/components/Logo';
import Reveal from '@/components/Reveal';
import { GENERAL_ORDER_URL } from '@/lib/whatsapp';

export default function Hero() {
  return (
    <section id="home" className="relative isolate flex min-h-[100svh] items-center overflow-hidden bg-forest-800">
      <ImageWithFallback
        src="/images/hero.jpg"
        alt=""
        className="absolute inset-0 -z-20 h-full w-full scale-105 object-cover animate-slow-zoom"
        fallback={
          <div className="absolute inset-0 -z-20 bg-gradient-to-br from-forest-900 via-forest-700 to-forest-600" />
        }
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-forest-900/95 via-forest-900/75 to-forest-900/30" />
      <div className="absolute inset-x-0 bottom-0 -z-10 h-40 bg-gradient-to-t from-cream-100 to-transparent" />

      <div className="mx-auto grid w-full max-w-7xl items-center gap-12 px-5 pb-24 pt-32 sm:px-8 lg:grid-cols-2 lg:gap-16 lg:pt-40">
        <div className="max-w-2xl">
          <Reveal className="mb-8">
            <Logo size="lg" />
          </Reveal>

          <Reveal delay={100}>
            <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-gold-300/40 bg-forest-900/40 px-4 py-1.5 text-xs font-medium uppercase tracking-[0.2em] text-gold-300 backdrop-blur-sm">
              <MapPin size={14} />
              Winneba Zongo, Ghana
            </p>
          </Reveal>

          <Reveal delay={200}>
            <h1 className="text-5xl font-semibold leading-[1.1] text-cream-50 sm:text-6xl lg:text-7xl">
              Welcome to Sally's Cuisine
              <span className="mt-3 block text-3xl italic text-gold-300 sm:text-4xl lg:text-5xl">
                Delicious Moments, Freshly Served.
              </span>
            </h1>
          </Reveal>

          <Reveal delay={300}>
            <p className="mt-6 max-w-xl text-base leading-relaxed text-cream-100/90 sm:text-lg">
              Come and enjoy delicious meals made fresh for you. Choose your favourite dish, then order
              directly on WhatsApp for pickup or delivery.
            </p>
          </Reveal>

          <Reveal delay={400}>
            <div className="mt-10 flex flex-col gap-4 sm:flex-row sm:items-center">
              <a
                href={GENERAL_ORDER_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-flex items-center justify-center gap-3 rounded-full bg-gold-500 px-8 py-4 text-base font-semibold text-forest-900 shadow-lift transition duration-300 hover:-translate-y-1 hover:bg-gold-400"
              >
                <MessageCircle size={20} />
                Order on WhatsApp
              </a>
              <a
                href="#menu"
                className="inline-flex items-center justify-center gap-2 rounded-full border border-cream-50/50 px-8 py-4 text-base font-medium text-cream-50 transition duration-300 hover:border-gold-300 hover:bg-cream-50/10 hover:text-gold-300"
              >
                Explore the menu
                <ArrowDown size={18} />
              </a>
            </div>
          </Reveal>
        </div>

        <Reveal delay={250} className="relative mx-auto w-full max-w-sm lg:mx-0 lg:max-w-md lg:justify-self-end">
          <div className="absolute -bottom-4 -left-4 h-full w-full rounded-[2rem] border border-gold-500/60 sm:-bottom-6 sm:-left-6" />
          <div className="relative aspect-[3/4] overflow-hidden rounded-[2rem] bg-forest-700 shadow-lift">
            <ImageWithFallback
              src="/images/sally.jpeg"
              alt="Sally, owner of Sally's Cuisine"
              className="absolute inset-0 h-full w-full object-cover object-top"
              fallback={
                <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-forest-600 to-forest-800">
                  <span className="font-display text-9xl font-semibold text-gold-300">S</span>
                </div>
              }
            />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
