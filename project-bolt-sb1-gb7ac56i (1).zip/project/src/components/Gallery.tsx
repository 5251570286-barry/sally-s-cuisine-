import ImageWithFallback from '@/components/ImageWithFallback';
import Reveal from '@/components/Reveal';
import { findMenuItem } from '@/data/menu';

const GALLERY_ITEMS = [
  { id: 'fried-yam', className: 'col-span-2 aspect-[4/3] lg:row-span-2 lg:aspect-auto' },
  { id: 'spaghetti', className: 'aspect-square' },
  { id: 'hot-tea', className: 'aspect-square' },
  { id: 'wheat-porridge', className: 'col-span-2 aspect-[16/9]' },
];

export default function Gallery() {
  return (
    <section id="gallery" className="relative overflow-hidden bg-forest-900 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-300">From Our Kitchen</p>
          <h2 className="mt-4 text-4xl font-semibold text-cream-50 sm:text-5xl">Food made to be savoured</h2>
          <div className="gold-rule mt-6" />
        </Reveal>

        <div className="mt-14 grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4 lg:auto-rows-[220px]">
          {GALLERY_ITEMS.map((entry, index) => {
            const item = findMenuItem(entry.id);
            if (!item) return null;
            const Icon = item.icon;
            return (
              <Reveal key={entry.id} delay={index * 100} className={`group relative overflow-hidden rounded-3xl bg-forest-700 ${entry.className}`}>
                <ImageWithFallback
                  src={item.image}
                  alt={`${item.name} from Sally's Cuisine`}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                  fallback={
                    <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-forest-600 to-forest-800 text-gold-300">
                      <Icon size={56} strokeWidth={1.2} />
                    </div>
                  }
                />
                <div className="absolute inset-0 bg-gradient-to-t from-forest-900/85 via-forest-900/10 to-transparent opacity-80 transition-opacity duration-500 group-hover:opacity-100" />
                <p className="absolute bottom-4 left-5 font-display text-2xl font-semibold text-cream-50 transition-transform duration-500 group-hover:-translate-y-1">
                  {item.name}
                </p>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
