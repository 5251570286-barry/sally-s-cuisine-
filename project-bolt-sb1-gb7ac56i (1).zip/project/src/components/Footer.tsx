import { MapPin, MessageCircle, Phone } from 'lucide-react';
import Logo from '@/components/Logo';
import { GENERAL_ORDER_URL, WHATSAPP_DISPLAY_NUMBER } from '@/lib/whatsapp';

const FOOTER_LINKS = [
  { href: '#home', label: 'Home' },
  { href: '#menu', label: 'Menu' },
  { href: '#gallery', label: 'Gallery' },
  { href: '#about', label: 'About Sally' },
  { href: '#contact', label: 'Contact' },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-forest-900 text-cream-100">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold-500/60 to-transparent" />

      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 sm:px-8 md:grid-cols-3 md:py-20">
        <div>
          <Logo size="sm" />
          <p className="mt-6 max-w-xs text-sm leading-relaxed text-cream-200/80">
            Delicious moments, freshly served. Good food, made with care in Winneba Zongo.
          </p>
        </div>

        <nav aria-label="Footer">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-300">Explore</p>
          <ul className="mt-5 grid grid-cols-2 gap-3 text-sm">
            {FOOTER_LINKS.map((link) => (
              <li key={link.href}>
                <a href={link.href} className="text-cream-100/80 transition hover:text-gold-300">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-300">Get in touch</p>
          <ul className="mt-5 space-y-4 text-sm">
            <li className="flex items-center gap-3 text-cream-100/80">
              <MapPin size={18} className="shrink-0 text-gold-300" />
              Winneba Zongo, Ghana
            </li>
            <li>
              <a
                href={GENERAL_ORDER_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-cream-100/80 transition hover:text-gold-300"
              >
                <Phone size={18} className="shrink-0 text-gold-300" />
                {WHATSAPP_DISPLAY_NUMBER}
              </a>
            </li>
          </ul>
          <a
            href={GENERAL_ORDER_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-gold-500 px-6 py-3 text-sm font-semibold text-forest-900 transition duration-300 hover:-translate-y-0.5 hover:bg-gold-400"
          >
            <MessageCircle size={17} />
            Order on WhatsApp
          </a>
        </div>
      </div>

      <div className="border-t border-cream-100/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-5 py-6 text-xs text-cream-200/70 sm:flex-row sm:px-8">
          <p>© {new Date().getFullYear()} Sally's Cuisine. All rights reserved.</p>
          <p>Winneba Zongo, Ghana</p>
        </div>
      </div>
    </footer>
  );
}
