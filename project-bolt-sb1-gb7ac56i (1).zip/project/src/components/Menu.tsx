import { useState } from 'react';
import { MessageCircle, Store, Truck, type LucideIcon } from 'lucide-react';
import ImageWithFallback from '@/components/ImageWithFallback';
import Reveal from '@/components/Reveal';
import { MENU_ITEMS, type MenuItem } from '@/data/menu';
import { buildMealOrderUrl, ORDER_TYPE_LABELS, type OrderType } from '@/lib/whatsapp';

const ORDER_TYPES: { value: OrderType; icon: LucideIcon }[] = [
  { value: 'pickup', icon: Store },
  { value: 'delivery', icon: Truck },
];

export default function Menu() {
  const [orderType, setOrderType] = useState<OrderType>('pickup');

  return (
    <section id="menu" className="relative bg-cream-100 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-700">Our Menu</p>
          <h2 className="mt-4 text-4xl font-semibold text-forest-900 sm:text-5xl">Freshly prepared favourites</h2>
          <div className="gold-rule mt-6" />
          <p className="mt-6 text-base leading-relaxed text-forest-700">
            Prices are not listed here. Tap a meal to message us on WhatsApp and ask about the price.
          </p>
        </Reveal>

        <Reveal delay={150} className="mt-10 flex flex-col items-center gap-3">
          <p className="text-sm font-medium text-forest-700">How would you like to receive your meal?</p>
          <div
            role="radiogroup"
            aria-label="Pickup or delivery"
            className="inline-flex rounded-full border border-forest-200 bg-cream-50 p-1.5 shadow-soft"
          >
            {ORDER_TYPES.map(({ value, icon: Icon }) => {
              const active = orderType === value;
              return (
                <button
                  key={value}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  onClick={() => setOrderType(value)}
                  className={`inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-all duration-300 ${
                    active
                      ? 'bg-forest-700 text-cream-50 shadow-soft'
                      : 'text-forest-700 hover:bg-forest-50 hover:text-forest-900'
                  }`}
                >
                  <Icon size={16} />
                  {ORDER_TYPE_LABELS[value]}
                </button>
              );
            })}
          </div>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 sm:gap-8 xl:grid-cols-4">
          {MENU_ITEMS.map((item, index) => (
            <Reveal key={item.id} delay={(index % 4) * 80}>
              <MenuCard item={item} orderType={orderType} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

interface MenuCardProps {
  item: MenuItem;
  orderType: OrderType;
}

function MenuCard({ item, orderType }: MenuCardProps) {
  const Icon = item.icon;

  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-3xl border border-forest-100 bg-cream-50 shadow-soft transition duration-500 hover:-translate-y-2 hover:shadow-lift">
      <div className="relative aspect-[4/3] overflow-hidden bg-forest-100">
        <ImageWithFallback
          src={item.image}
          alt={`${item.name} served at Sally's Cuisine`}
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          fallback={
            <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-forest-100 to-cream-200 text-forest-600">
              <Icon size={48} strokeWidth={1.4} />
            </div>
          }
        />
      </div>

      <div className="flex flex-1 flex-col p-6">
        <h3 className="text-2xl font-semibold text-forest-900">{item.name}</h3>
        <p className="mt-1 text-sm text-forest-600">Ask about price on WhatsApp</p>
        <div className="mt-auto pt-6">
          <a
            href={buildMealOrderUrl(item.name, orderType)}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Order ${item.name} for ${ORDER_TYPE_LABELS[orderType].toLowerCase()} on WhatsApp`}
            className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-forest-700 px-5 py-3 text-sm font-semibold text-cream-50 transition duration-300 hover:-translate-y-0.5 hover:bg-forest-600 hover:shadow-soft"
          >
            <MessageCircle size={17} />
            Order on WhatsApp
          </a>
        </div>
      </div>
    </article>
  );
}
