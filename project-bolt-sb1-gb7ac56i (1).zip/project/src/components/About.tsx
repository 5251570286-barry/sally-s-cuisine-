import { MessageCircle } from 'lucide-react';
import ImageWithFallback from '@/components/ImageWithFallback';
import Reveal from '@/components/Reveal';
import { GENERAL_ORDER_URL } from '@/lib/whatsapp';

export default function About() {
  return (
    <section id="about" className="relative bg-cream-100 py-24 sm:py-32">
      <div className="mx-auto grid max-w-7xl items-center gap-16 px-5 sm:px-8 lg:grid-cols-2 lg:gap-24">
        <Reveal className="relative mx-auto w-full max-w-md lg:mx-0">
          <div className="absolute -right-4 -top-4 h-full w-full rounded-[2rem] border border-gold-500/60 sm:-right-6 sm:-top-6" />
          <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem] bg-forest-100 shadow-lift">
            <ImageWithFallback
              src="/images/sally.jpg"
              alt="Sally, owner of Sally's Cuisine"
              className="absolute inset-0 h-full w-full object-cover"
              fallback={
                <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-forest-600 to-forest-800">
                  <span className="font-display text-9xl font-semibold text-gold-300">S</span>
                </div>
              }
            />
          </div>
        </Reveal>

        <Reveal delay={150}>
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-gold-700">About Sally</p>
          <h2 className="mt-4 text-4xl font-semibold leading-tight text-forest-900 sm:text-5xl">
            Warm hospitality, served on every plate
          </h2>
          <div className="mt-6 h-px w-16 bg-gold-500" />
          <div className="mt-8 space-y-5 text-base leading-relaxed text-forest-700">
            <p>
              Welcome to Sally's Cuisine in Winneba Zongo. Sally brings a personal touch to every meal she prepares,
              from a comforting bowl of porridge to a plate of fried yam and everything in between.
            </p>
            <p>
              Our kitchen is built on fresh ingredients, careful cooking and a genuine welcome for every customer. We
              hope every visit leaves you satisfied and ready to come back.
            </p>
          </div>

          <a
            href={GENERAL_ORDER_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-10 inline-flex items-center gap-3 rounded-full bg-forest-700 px-7 py-4 text-sm font-semibold text-cream-50 shadow-soft transition duration-300 hover:-translate-y-1 hover:bg-forest-600 hover:shadow-lift"
          >
            <MessageCircle size={18} />
            Order on WhatsApp
          </a>
        </Reveal>
      </div>
    </section>
  );
}
