import { ChefHat } from 'lucide-react';
import ImageWithFallback from '@/components/ImageWithFallback';

interface LogoProps {
  size?: 'sm' | 'lg';
}

const IMAGE_HEIGHT = {
  sm: 'h-10 sm:h-12',
  lg: 'h-20 sm:h-24',
};

export default function Logo({ size = 'sm' }: LogoProps) {
  return (
    <span className="inline-flex items-center rounded-2xl bg-cream-50 px-4 py-2 shadow-soft ring-1 ring-gold-500/30">
      <ImageWithFallback
        src="/images/logo.png"
        alt="Sally's Cuisine logo"
        className={`w-auto object-contain ${IMAGE_HEIGHT[size]}`}
        fallback={
          <span className="flex items-center gap-3 text-forest-900">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gold-500 text-forest-900">
              <ChefHat size={20} strokeWidth={1.8} />
            </span>
            <span className="font-display text-2xl font-semibold tracking-wide">Sally's Cuisine</span>
          </span>
        }
      />
    </span>
  );
}
