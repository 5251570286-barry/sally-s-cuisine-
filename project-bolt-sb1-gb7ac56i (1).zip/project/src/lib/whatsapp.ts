export const WHATSAPP_NUMBER = '233240954416';
export const WHATSAPP_DISPLAY_NUMBER = '0240954416';

export type OrderType = 'pickup' | 'delivery';

export const ORDER_TYPE_LABELS: Record<OrderType, string> = {
  pickup: 'Pickup',
  delivery: 'Delivery',
};

function buildWhatsAppUrl(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export const GENERAL_ORDER_URL = buildWhatsAppUrl(
  "Hello Sally's Cuisine, I would like to place an order. Could you please share the prices?",
);

export function buildMealOrderUrl(mealName: string, orderType: OrderType) {
  const type = ORDER_TYPE_LABELS[orderType].toLowerCase();
  return buildWhatsAppUrl(
    `Hello Sally's Cuisine, I would like to order ${mealName} for ${type}. Could you please confirm the price?`,
  );
}
