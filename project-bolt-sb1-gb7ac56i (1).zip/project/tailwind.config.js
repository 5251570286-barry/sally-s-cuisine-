/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        forest: {
          50: '#eef5f1',
          100: '#d7e7dd',
          200: '#afd0bd',
          300: '#82b59a',
          400: '#4f8f71',
          500: '#2f6e53',
          600: '#22553f',
          700: '#1a4330',
          800: '#123224',
          900: '#0c2419',
        },
        cream: {
          50: '#fdfbf5',
          100: '#f8f3e6',
          200: '#f0e7d0',
          300: '#e4d6b4',
        },
        gold: {
          100: '#f7eed2',
          300: '#e3c77f',
          400: '#d4b162',
          500: '#c9a24b',
          700: '#8a6a22',
        },
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['Manrope', 'system-ui', 'sans-serif'],
      },
      keyframes: {
        'slow-zoom': {
          from: { transform: 'scale(1.12)' },
          to: { transform: 'scale(1.02)' },
        },
      },
      animation: {
        'slow-zoom': 'slow-zoom 24s ease-out forwards',
      },
      boxShadow: {
        soft: '0 10px 40px -12px rgba(12, 36, 25, 0.25)',
        lift: '0 24px 60px -20px rgba(12, 36, 25, 0.35)',
      },
    },
  },
  plugins: [],
};
